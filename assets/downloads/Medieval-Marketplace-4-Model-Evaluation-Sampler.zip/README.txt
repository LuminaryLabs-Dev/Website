Medieval Marketplace / Luminary Labs
Free Evaluation Sampler v0.1
Contains four models: market stall, signpost, stool and chest.
Source: LAU-PACK-018, 66-model DRAFT collection.
GLB 2.0 models are experimental and not verified in Unity, Unreal or other target engines.
For personal/private evaluation only. Commercial use and redistribution are not granted by this preview.
For license or support, visit https://luminarylabs.dev/contact.html
