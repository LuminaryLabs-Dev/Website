using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using Camel.Native;
public static class ExportBuild {
 public static void Prepare(){
  NativeChecks.Run();
  var game=JsonUtility.FromJson<ExportGame>(File.ReadAllText("Assets/Resources/game.json"));
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var camera=new GameObject("Main Camera");camera.tag="MainCamera";camera.AddComponent<Camera>();camera.AddComponent<AudioListener>();
  var sun=new GameObject("Authored sunlight").AddComponent<Light>();sun.type=LightType.Directional;sun.transform.rotation=Quaternion.Euler(45,-35,0);sun.shadows=LightShadows.Soft;
  new GameObject("Native authored game").AddComponent<NativePlayer>();
  Directory.CreateDirectory("Assets/Scenes");EditorSceneManager.SaveScene(scene,"Assets/Scenes/Game.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/Game.unity",true)};
  PlayerSettings.companyName="CAMEL";PlayerSettings.productName=game.title;PlayerSettings.colorSpace=ColorSpace.Linear;PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
  PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.Android,"dev.luminarylabs.camel.g"+game.sourceRunId.Replace("-",""));
  PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel26;
  PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64|AndroidArchitecture.X86_64;
  // Development artifacts favor debuggability; release optimization needs its own gate.
  PlayerSettings.SetIl2CppCompilerConfiguration(UnityEditor.Build.NamedBuildTarget.Android,Il2CppCompilerConfiguration.Debug);
  AssetDatabase.SaveAssets();File.WriteAllText("compile-receipt.json",JsonUtility.ToJson(new Receipt{status="compiled",sourceHash=game.sourceHash,targetVerified=false},true));
 }
 public static void Windows(){Prepare();Directory.CreateDirectory("Builds/Windows");var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/Game.unity"},locationPathName="Builds/Windows/Game.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.Development});if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Windows build failed: "+report.summary.result);}
 public static void Android(){Prepare();EditorUserBuildSettings.buildAppBundle=false;Directory.CreateDirectory("Builds");var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/Game.unity"},locationPathName="Builds/game.apk",target=BuildTarget.Android,options=BuildOptions.Development});if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Android build failed: "+report.summary.result);File.WriteAllText("android-build-receipt.json",JsonUtility.ToJson(new Receipt{status="built",sourceHash=JsonUtility.FromJson<ExportGame>(File.ReadAllText("Assets/Resources/game.json")).sourceHash,targetVerified=false},true));}
 [Serializable]public class Receipt{public string status,sourceHash;public bool targetVerified;}
}
