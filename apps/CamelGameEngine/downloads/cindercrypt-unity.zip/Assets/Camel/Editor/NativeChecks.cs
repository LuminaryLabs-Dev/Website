using System;
using System.IO;
using Camel.Native;
using UnityEngine;
public static class NativeChecks {
 [Serializable]public class Field{public string key;public double value;}
 [Serializable]public class Step{public Controls input;public string status;public Field[] fields;}
 [Serializable]public class Case{public string profile,mode;public Step[] steps;}
 [Serializable]public class Floor{public string seed;public int floor,size;public bool endless;public Vector2Int start,stairs;public bool[] cells;}
 [Serializable]public class Suite{public Case[] tests;public Floor[] floors;}
 public static void Run(){int count=0;var suite=JsonUtility.FromJson<Suite>(File.ReadAllText("Assets/Resources/reference.json"));foreach(var test in suite.tests){
  IGameAdapter adapter=test.profile=="flight-collectathon"?(IGameAdapter)new FlightAdapter(new Tuning()):new RunnerAdapter(new Tuning());
  foreach(var step in test.steps){adapter.Step(1.0/60,step.input);if(adapter.Status!=step.status)throw new Exception(test.profile+" "+test.mode+" status mismatch at "+count+": "+adapter.Status+" != "+step.status);
   foreach(var field in step.fields){var member=adapter.GetType().GetField(field.key);if(member==null)throw new Exception("Missing state "+field.key);var actual=Convert.ToDouble(member.GetValue(adapter));if(Math.Abs(actual-field.value)>.0001)throw new Exception(test.profile+" "+test.mode+" "+field.key+" mismatch at "+count+": "+actual+" != "+field.value);}count++;
  }adapter.Restart();if(adapter.Status!="playing"||adapter.Position.sqrMagnitude>.0001)throw new Exception("Restart failed");
 }foreach(var expected in suite.floors){var actual=new Dungeon(expected.seed,expected.floor,expected.endless);if(actual.size!=expected.size||actual.start!=expected.start||actual.stairs!=expected.stairs)throw new Exception("Dungeon dimensions or endpoints differ");for(int i=0;i<expected.cells.Length;i++)if(actual.cells[i]!=expected.cells[i])throw new Exception("Dungeon cell differs: "+expected.seed+" floor "+expected.floor+" cell "+i);}
 File.WriteAllText("native-checks.json","{\"passed\":true,\"traceSteps\":"+count+",\"floorLayouts\":"+suite.floors.Length+",\"sourceParityScope\":\"default flight and runner sampled simulation fields; seeded dungeon geometry\",\"targetVerified\":false}");}
}
