using System;
using UnityEngine;
using System.Collections.Generic;
namespace Camel.Native {
 [Serializable] public class ExportGame { public string schema,title,sourceRunId,sourceHash,ruleset,seed; public string[] profiles; public MeshData[] meshes; public SceneData[] scenes; }
 [Serializable] public class MeshData { public string id; public float[] positions,colors,normals; public int[] indices; }
 [Serializable] public class SceneData { public string id,name,profile; public float bounds,seconds; public int goal; public ObjectData[] objects; public Tuning tuning=new Tuning(); public Art art=new Art(); }
 [Serializable] public class ObjectData { public string id,name,role,meshRecipe,meshId; public float x,y,z,sx=1,sy=1,sz=1,roughness=.6f,metallic; public float[] color,emission; }
 [Serializable] public class Art { public string subtitle,skyTop,skyBottom,fogColor,sunColor,accentColor; public float ambientIntensity=.8f,sunIntensity=2,keyIntensity=2,exposure=1,fogNear=60,fogFar=180,heroScale=3; public bool enabled; }
 [Serializable] public class Tuning {
  public bool jumping=true,rolling=true,followCamera=true; public float playerSpeed=4,gravity=18,acceleration=12,jumpSpeed=7,killY=-8,cameraX=8,cameraY=12,cameraZ=18,cameraFov=50;
  public float vehicleAcceleration=90,vehicleMaxSpeed=150,vehicleTurnRate=5,vehicleDrag=.9f,boostMax=100;
  public float hazardSpawnInterval=8,hazardSpeed=5,hazardRadius=.6f,hazardDamage=10,startingHealth=28;
  public float startingCash=500,facilityCost=100,facilityRevenue=25,facilityInterval=5,targetCash=1000;
  public float runnerStartSpeed=8,runnerMaxSpeed=16,runnerRampSeconds=120,runnerMilestone=1000,runnerDifficultySeconds=180,runnerStartInterval=2.8f,runnerMinInterval=1.15f; public int runnerSeed=37;
  public float flightRadius=10,flightLateralSpeed=7,flightStartSpeed=10,flightMaxSpeed=18,flightDifficultySeconds=180,flightMilestone=1000,flightCameraDistance=6.5f; public int flightSeed=89;
  public int baseAttack=2,baseDefense=0; public float enemyHealthScale=1,enemyAttackScale=1;
 }
 [Serializable] public struct Controls { public double x,y; public bool jump,jumpReleased,slide,boost,interact; }
 public class Actor { public string id,role,recipe; public Vector3 position,scale=Vector3.one; public Color tint=Color.white; }
 public interface IGameAdapter { string Status{get;} string Hud{get;} Vector3 Position{get;} IEnumerable<Actor> Actors{get;} void Step(double dt,Controls input); void Restart(); }
 public static class Numbers {
  public static double Clamp(double x,double a,double b)=>Math.Max(a,Math.Min(b,x));
  public static double Hypot(double x,double y)=>Math.Sqrt(x*x+y*y);
  public static uint Pattern(int index,int seed){unchecked{uint n=(uint)(index+1)*2654435761u^(uint)seed;n=(n^(n>>16))*2246822507u;return n^(n>>13);}}
 }
}
