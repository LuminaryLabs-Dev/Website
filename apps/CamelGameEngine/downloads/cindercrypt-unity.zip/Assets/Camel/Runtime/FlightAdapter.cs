using System;
using System.Collections.Generic;
using UnityEngine;
namespace Camel.Native {
 public sealed class FlightAdapter:IGameAdapter {
  public sealed class Point { public double x,y,distance,radius; public bool collected; }
  public sealed class Segment { public int index; public double x,y,distance,gapRadius; public bool passed; public List<Point> feathers=new List<Point>(),hazards=new List<Point>(); }
  readonly Tuning t; public double elapsed,distance,x,y,vx,vy,speed,difficulty,multiplier; public int coins,ringsPassed,ringMisses,nextSegment; public List<Segment> segments=new List<Segment>();
  public string Status{get;private set;}="playing"; public string cause;
  double radius,lateral,start,max,seconds;
  public FlightAdapter(Tuning tuning){t=tuning;radius=Numbers.Clamp(t.flightRadius,8,16);lateral=Numbers.Clamp(t.flightLateralSpeed,4,12);start=Numbers.Clamp(t.flightStartSpeed,6,14);max=Numbers.Clamp(t.flightMaxSpeed,start,22);seconds=Numbers.Clamp(t.flightDifficultySeconds,60,600);Restart();}
  public Vector3 Position=>new Vector3((float)x,(float)y,0);
  public string Hud=>$"{Math.Floor(distance)} m   Feathers {coins}   Rings {ringsPassed}   Misses {ringMisses}/3";
  public void Restart(){elapsed=distance=x=y=vx=vy=difficulty=0;speed=start;multiplier=1;coins=ringsPassed=ringMisses=nextSegment=0;segments.Clear();Status="playing";cause=null;Fill();}
  public Segment MakeSegment(int i,Segment prev){
   uint r=Numbers.Pattern(i,t.flightSeed);double angle=(r%6283)/1000.0,progression=Math.Min(1,Math.Log(1+i/8.0)/Math.Log(15)),baseDistance=prev?.distance??30;
   double targetDistance=baseDistance+42+((r>>4)%1000)/1000.0*23;
   double maxOffset=Math.Min(lateral*((targetDistance-baseDistance)/max)-1.35,radius*.45);
   double px=prev?.x??0,py=prev?.y??0;
   var row=new Segment{index=i,distance=targetDistance,x=px+Math.Cos(angle)*maxOffset*(.5+(r>>12)%100/200.0),y=py+Math.Sin(angle)*maxOffset*(.5+(r>>16)%100/200.0),gapRadius=Math.Max(2.2,2.8-.6*progression)};
   double length=Numbers.Hypot(row.x,row.y);if(length>radius*.55){row.x*=radius*.55/length;row.y*=radius*.55/length;}
   if(i%2==1){
    double span=Numbers.Hypot(row.x-px,row.y-py),hx=px+Math.Cos(angle)*span*.5,hy=py+Math.Sin(angle)*span*.5;
    row.hazards.Add(new Point{x=hx,y=hy,distance=targetDistance-12,radius=.8});double wx=hx+Math.Cos(angle+Math.PI/2)*3.5,wy=hy+Math.Sin(angle+Math.PI/2)*3.5;
    double wr=Numbers.Hypot(wx,wy);if(wr>radius*.7){wx*=radius*.7/wr;wy*=radius*.7/wr;}
    double time=(Numbers.Hypot(wx-px,wy-py)+Numbers.Hypot(row.x-wx,row.y-wy))/lateral,total=(targetDistance-baseDistance)/max;
    if(time>total){double k=total/time;wx=hx+Math.Cos(angle+Math.PI/2)*3.5*k;wy=hy+Math.Sin(angle+Math.PI/2)*3.5*k;}
    for(int j=0;j<5;j++){double f=(j+1)/5.0,a=f<.5?f*2:(f-.5)*2;row.feathers.Add(f<.5?new Point{x=px*(1-a)+wx*a,y=py*(1-a)+wy*a,distance=baseDistance+(targetDistance-baseDistance)*a*.5}:new Point{x=wx*(1-a)+row.x*a,y=wy*(1-a)+row.y*a,distance=baseDistance+(targetDistance-baseDistance)*(.5+a*.5)});}
   }else for(int j=0;j<5;j++){double f=(j+1)/5.0;row.feathers.Add(new Point{x=px*(1-f)+row.x*f,y=py*(1-f)+row.y*f,distance=targetDistance-10+j*4});}
   return row;
  }
  void Fill(){while(segments.Count==0||segments[segments.Count-1].distance<distance+180)segments.Add(MakeSegment(nextSegment++,segments.Count==0?null:segments[segments.Count-1]));if(segments.Count>16)throw new InvalidOperationException("Flight pool exceeded");}
  public void Step(double dt,Controls input){
   if(Status!="playing")return;if(dt<=0||dt>.05)throw new ArgumentOutOfRangeException(nameof(dt));
   elapsed+=dt;difficulty=Math.Min(1,Math.Log(1+elapsed/30)/Math.Log(1+seconds/30));speed=start+(max-start)*difficulty;distance+=speed*dt;
   double ix=Numbers.Clamp(input.x,-1,1),iy=Numbers.Clamp(input.y,-1,1),mag=Numbers.Hypot(ix,iy);if(mag>1){ix/=mag;iy/=mag;}double blend=1-Math.Exp(-14*dt);vx+=(ix*lateral-vx)*blend;vy+=(iy*lateral-vy)*blend;x+=vx*dt;y+=vy*dt;
   if(Numbers.Hypot(x,y)>radius-.35){Status="lost";cause="cylinder-boundary";}
   foreach(var row in segments){foreach(var h in row.hazards)if(Math.Sqrt((x-h.x)*(x-h.x)+(y-h.y)*(y-h.y)+(distance-h.distance)*(distance-h.distance))<h.radius+.32){Status="lost";cause="floating-ruin";}
    foreach(var coin in row.feathers)if(!coin.collected&&Status=="playing"&&Math.Sqrt((x-coin.x)*(x-coin.x)+(y-coin.y)*(y-coin.y)+(distance-coin.distance)*(distance-coin.distance))<1){coin.collected=true;coins++;multiplier=Math.Min(5,1+Math.Floor(coins/10.0)*.25);}
    if(row.distance-distance< -1&&!row.passed){row.passed=true;if(Numbers.Hypot(x-row.x,y-row.y)<row.gapRadius)ringsPassed++;else{ringMisses++;if(ringMisses>=3){Status="lost";cause="missed-rings";}}}
   }
   while(segments.Count>0&&segments[0].distance<distance-15)segments.RemoveAt(0);Fill();
  }
  public IEnumerable<Actor> Actors{get{
   yield return new Actor{id="hero",role="player",recipe="bird",position=Position,scale=Vector3.one*3};
   foreach(var row in segments){yield return new Actor{id="ring-"+row.index,role="decoration",recipe="hoop",position=new Vector3((float)row.x,(float)row.y,(float)(row.distance-distance)),scale=Vector3.one*(float)(row.gapRadius*2)};
    for(int j=0;j<row.feathers.Count;j++){var p=row.feathers[j];if(!p.collected)yield return new Actor{id=$"feather-{row.index}-{j}",role="collectible",recipe="crystal",position=new Vector3((float)p.x,(float)p.y,(float)(p.distance-distance)),scale=new Vector3(.45f,.75f,.45f)};}
    for(int j=0;j<row.hazards.Count;j++){var p=row.hazards[j];yield return new Actor{id=$"hazard-{row.index}-{j}",role="hazard",recipe="rock",position=new Vector3((float)p.x,(float)p.y,(float)(p.distance-distance)),scale=Vector3.one*(float)(p.radius*2)};}
   }
  }}
 }
}
