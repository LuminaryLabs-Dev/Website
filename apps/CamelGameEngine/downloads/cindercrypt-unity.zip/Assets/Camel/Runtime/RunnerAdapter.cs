using System;
using System.Collections.Generic;
using UnityEngine;
namespace Camel.Native {
 public sealed class RunnerAdapter:IGameAdapter {
  public sealed class Row { public int index,coinLane,coins;public double distance,arrivalTime,interval;public string[] lanes;public bool passed; }
  readonly Tuning t;readonly double start,max,ramp,difficultySeconds,startInterval,minInterval;
  public double elapsed,distance,speed,difficulty,x,y,vy,laneFrom,laneTime,lastGrounded,jumpBuffer,jumpStarted,slideUntil;public bool jumpCut;public int lane,coins,nextRow; public List<Row> rows=new List<Row>();
  public string Status{get;private set;}="playing";public string cause;
  public Vector3 Position=>new Vector3((float)x,(float)y,0); public string Hud=>$"{Math.Floor(distance)} m   Salvage {coins}   Intensity {difficulty:P0}";
  public RunnerAdapter(Tuning tuning){t=tuning;start=Numbers.Clamp(t.runnerStartSpeed,6,12);max=Numbers.Clamp(t.runnerMaxSpeed,start,18);ramp=Numbers.Clamp(t.runnerRampSeconds,30,300);difficultySeconds=Numbers.Clamp(t.runnerDifficultySeconds,60,600);startInterval=Numbers.Clamp(t.runnerStartInterval,2,4);minInterval=Numbers.Clamp(t.runnerMinInterval,1.1,1.8);Restart();}
  public void Restart(){elapsed=distance=difficulty=x=y=vy=laneFrom=lastGrounded=slideUntil=0;laneTime=.12;jumpBuffer=jumpStarted=-1;jumpCut=false;lane=coins=nextRow=0;speed=start;rows.Clear();Status="playing";cause=null;Fill();}
  double Difficulty(double time)=>Numbers.Clamp(Math.Log(1+Math.Max(0,time)/30)/Math.Log(1+difficultySeconds/30),0,1);
  double DistanceAt(double time){double r=Math.Min(time,ramp);return start*r+(max-start)*r*r/(2*ramp)+Math.Max(0,time-ramp)*max;}
  double TimeAt(double d){double rd=(start+max)*ramp/2,rate=(max-start)/ramp;return d>rd?ramp+(d-rd)/max:rate>0?(Math.Sqrt(start*start+2*rate*d)-start)/rate:d/start;}
  public Row MakeRow(int index,Row previous){uint r=Numbers.Pattern(index,t.runnerSeed);double jitter=.9+r%1001/1000.0*.35,d=Difficulty(previous?.arrivalTime??0),interval=index==0?0:Math.Max(1.1,(startInterval-(startInterval-minInterval)*d)*jitter),arrival=index==0?TimeAt(48):previous.arrivalTime+interval;var row=new Row{index=index,distance=DistanceAt(arrival),arrivalTime=arrival,interval=interval,lanes=new string[3]};string[] kinds={"barrier","pipe","gap"};
   for(int i=0;i<3;i++)row.lanes[i]=index<3?kinds[index]:index%4==0?(index%8==0?"barrier":"gap"):index%4==2?"pipe":kinds[(int)(((ulong)r+(uint)i)%3)];
   if(index>=3&&index%2==1&&(r>>8)%100>20+Difficulty(arrival)*65)row.lanes[r%3]="clear";
   var blocked=new List<int>();for(int i=0;i<3;i++)if(row.lanes[i]!="clear")blocked.Add(i);row.coinLane=blocked[(int)((r>>12)%(uint)blocked.Count)]-1;return row;
  }
  void Fill(){while(rows.Count==0||rows[rows.Count-1].distance<distance+144)rows.Add(MakeRow(nextRow++,rows.Count==0?null:rows[rows.Count-1]));if(rows.Count>26)throw new InvalidOperationException("Runner pool exceeded");}
  public void Step(double dt,Controls input){if(Status!="playing")return;if(dt<=0||dt>.05)throw new ArgumentOutOfRangeException(nameof(dt));elapsed+=dt;speed=start+(max-start)*Math.Min(1,elapsed/ramp);difficulty=Difficulty(elapsed);distance+=speed*dt;
   if(input.x!=0){int next=(int)Numbers.Clamp(lane+Math.Sign(input.x),-1,1);if(next!=lane){laneFrom=x;laneTime=0;lane=next;}}
   laneTime=Math.Min(.12,laneTime+dt);double ease=1-Math.Pow(1-laneTime/.12,3);x=laneFrom+(lane*2.6-laneFrom)*ease;
   if(input.jump){jumpBuffer=elapsed+.12;jumpCut=false;}if(input.slide&&y<.1){slideUntil=elapsed+.65;jumpBuffer=-1;}
   bool inGap=rows.Exists(row=>Math.Abs(row.distance-distance)<2&&((row.lanes[0]=="gap"&&Math.Abs(x+2.6)<1.05)||(row.lanes[1]=="gap"&&Math.Abs(x)<1.05)||(row.lanes[2]=="gap"&&Math.Abs(x-2.6)<1.05)));
   bool grounded=y<=0&&!inGap;if(grounded){lastGrounded=elapsed;y=vy=0;}if(jumpBuffer>=elapsed&&elapsed-lastGrounded<=.1){vy=8.2;jumpBuffer=-1;slideUntil=0;lastGrounded=-1;jumpStarted=elapsed;}
   if(input.jumpReleased)jumpCut=true;if(jumpCut&&elapsed-jumpStarted>=.12&&vy>3.8)vy=3.8;if(!grounded||vy>0){vy-=22*dt;y+=vy*dt;}if(y<0&&!inGap){y=vy=0;}bool sliding=slideUntil>elapsed&&y<.1;
   foreach(var row in rows){double delta=row.distance-distance;for(int i=0;i<3;i++){string kind=row.lanes[i];if(Math.Abs(x-(i-1)*2.6)>.92)continue;if(Math.Abs(delta)<1.05&&((kind=="barrier"&&y<.92)||(kind=="pipe"&&(!sliding||y>.1)))){Status="lost";cause=kind;}}
    string coinKind=row.lanes[row.coinLane+1];bool evading=coinKind=="pipe"?sliding:coinKind=="barrier"?y>=.92:y>.2;
    for(int c=0;c<3;c++)if(Status=="playing"&&evading&&(row.coins&(1<<c))==0&&Math.Abs(delta-1.5+c*1.5)<.6&&Math.Abs(x-row.coinLane*2.6)<.85){row.coins|=1<<c;coins++;}
   }
   if(y< -1.8){Status="lost";cause="gap";}while(rows.Count>0&&rows[0].distance<distance-10)rows.RemoveAt(0);Fill();
  }
  public IEnumerable<Actor> Actors{get{
   yield return new Actor{id="hero",role="player",recipe="character",position=Position+Vector3.up*.6f,scale=new Vector3(.8f,slideUntil>elapsed?.5f:1.2f,.8f)};
   // Road chunks reuse the authored platform asset; no procedural mesh is created.
   for(int i=-1;i<7;i++)yield return new Actor{id="road-"+i,role="platform",recipe="slab",position=new Vector3(0,-.3f,i*24-(float)(distance%24)),scale=new Vector3(8,.5f,24)};
   foreach(var row in rows){for(int l=0;l<3;l++){var kind=row.lanes[l];if(kind=="clear")continue;yield return new Actor{id=$"obstacle-{row.index}-{l}",role=kind=="gap"?"decoration":"hazard",recipe=kind=="pipe"?"arch":kind=="gap"?"slab":"prop",position=new Vector3((float)((l-1)*2.6),kind=="pipe"?1.4f:kind=="gap"?.02f:.5f,(float)(row.distance-distance)),scale=new Vector3(2.1f,kind=="gap"?.03f:1,kind=="gap"?4:1),tint=kind=="gap"?Color.black:Color.white};}
    for(int c=0;c<3;c++)if((row.coins&(1<<c))==0)yield return new Actor{id=$"coin-{row.index}-{c}",role="collectible",recipe="crystal",position=new Vector3((float)(row.coinLane*2.6),1.3f,(float)(row.distance-distance-1.5+c*1.5)),scale=Vector3.one*.4f};
   }
  }}
 }
}
