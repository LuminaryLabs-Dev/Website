using UnityEngine;
namespace Camel.Native {
 [RequireComponent(typeof(Camera))] public sealed class SourceToneMapping:MonoBehaviour {
  public float exposure=1.35f;Material material;
  void OnEnable(){GetComponent<Camera>().depthTextureMode|=DepthTextureMode.Depth;}
  void OnRenderImage(RenderTexture source,RenderTexture destination){if(material==null){var shader=Shader.Find("Hidden/Camel/SourceACES");if(shader==null)throw new System.InvalidOperationException("Missing source ACES shader");material=new Material(shader);}material.SetFloat("_Exposure",exposure);Graphics.Blit(source,destination,material);}
  void OnDestroy(){if(material!=null)Destroy(material);}
 }
}
