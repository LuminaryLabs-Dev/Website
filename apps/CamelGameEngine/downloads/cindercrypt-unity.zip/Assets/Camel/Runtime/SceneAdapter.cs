using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
namespace Camel.Native {
 // Native scene-controller candidate. Its export receipt requires target playtest;
 // source browser verification alone never certifies these physics semantics.
 public sealed class SceneAdapter:IGameAdapter {
  readonly SceneData scene;readonly Tuning t;readonly ObjectData hero;Vector3 position,velocity,checkpoint;readonly HashSet<string> collected=new HashSet<string>();
  sealed class Hazard {public string id;public double x,z,vx,vz,radius;}
  readonly List<Hazard> hazards=new List<Hazard>();readonly List<double> facilityDue=new List<double>();
  public double elapsed,health,cash,boost,heading=-Math.PI/2;double invulnerable,nextSpawn;int spawned;
  public string Status{get;private set;}="playing";public Vector3 Position=>position;
  public string Hud=>scene.profile=="management-sim"?$"Cash {cash:0} / {t.targetCash:0}   Facilities {facilityDue.Count}":scene.profile=="hazard-survival"?$"Health {health:0}   Survive {Math.Max(0,scene.seconds-elapsed):0}s":$"Collected {collected.Count}/{scene.goal}   {Math.Max(0,scene.seconds-elapsed):0}s";
  public SceneAdapter(SceneData data){scene=data;t=data.tuning;hero=data.objects.FirstOrDefault(o=>o.role=="player")??throw new InvalidOperationException("Missing player");Restart();}
  public void Restart(){Status="playing";position=checkpoint=new Vector3(hero.x,hero.y,hero.z);velocity=Vector3.zero;elapsed=invulnerable=0;health=t.startingHealth;cash=t.startingCash;boost=t.boostMax;heading=-Math.PI/2;collected.Clear();hazards.Clear();facilityDue.Clear();spawned=0;nextSpawn=t.hazardSpawnInterval;
   int i=0;foreach(var o in scene.objects){if(o.role=="hazard")hazards.Add(new Hazard{id=o.id,x=o.x,z=o.z,vx=(i%2!=0?1:-1)*t.hazardSpeed,vz=(i++%3!=0?-1:1)*t.hazardSpeed*.45,radius=Math.Max(.1,Math.Min(o.sx,o.sz)/2)});if(o.role=="facility")facilityDue.Add(t.facilityInterval);}
  }
  public bool BuildFacility(){if(Status!="playing"||cash<t.facilityCost||facilityDue.Count>=128)return false;cash-=t.facilityCost;facilityDue.Add(elapsed+t.facilityInterval);return true;}
  void Drive(double dt,Controls input){
   double angle=input.x*t.vehicleTurnRate*dt,cos=Math.Cos(angle),sin=Math.Sin(angle),ox=velocity.x,oz=velocity.z;
   double rx=ox*cos-oz*sin,rz=ox*sin+oz*cos;bool active=input.boost&&boost>0;double mul=active?1.8:1;
   double ix=Math.Cos(heading)*-input.y,iz=Math.Sin(heading)*-input.y,m=Numbers.Hypot(ix,iz);double vx=ox,vz=oz;if(m>0){vx+=ix/m*t.vehicleAcceleration*mul*dt;vz+=iz/m*t.vehicleAcceleration*mul*dt;}vx+=rx-ox;vz+=rz-oz;
   boost=Numbers.Clamp(boost+(active?-20:12)*dt,0,t.boostMax);double drag=Math.Max(0,1-t.vehicleDrag*dt);vx*=drag;vz*=drag;double speed=Numbers.Hypot(vx,vz),limit=t.vehicleMaxSpeed*mul;if(speed>limit){vx*=limit/speed;vz*=limit/speed;}
   position.x+=(float)(vx*dt);position.z+=(float)(vz*dt);if(Math.Abs(position.x)>scene.bounds||Math.Abs(position.z)>scene.bounds){position.x=Mathf.Clamp(position.x,-scene.bounds,scene.bounds);position.z=Mathf.Clamp(position.z,-scene.bounds,scene.bounds);vx*= -.55;vz*= -.55;}if(Numbers.Hypot(vx,vz)>1e-6)heading=Math.Atan2(vz,vx);velocity=new Vector3((float)vx,0,(float)vz);
  }
  void Walk(double dt,Controls input){
   Vector3 direction=new Vector3((float)input.x,0,(float)-input.y);if(direction.sqrMagnitude>1)direction.Normalize();velocity.x=Mathf.MoveTowards(velocity.x,direction.x*t.playerSpeed,t.acceleration*(float)dt);velocity.z=Mathf.MoveTowards(velocity.z,direction.z*t.playerSpeed,t.acceleration*(float)dt);
   float radius=Mathf.Max(.2f,hero.sy/2),surface=float.NegativeInfinity;
   foreach(var o in scene.objects)if((o.role=="platform"||o.role=="moving-platform")&&Math.Abs(position.x-o.x)<=o.sx/2&&Math.Abs(position.z-o.z)<=o.sz/2&&position.y>=o.y+o.sy/2+radius-.15f)surface=Mathf.Max(surface,o.y+o.sy/2+radius);
   bool grounded=position.y<=surface+.05f;if(!t.rolling&&scene.profile!="adventure"){surface=hero.y;grounded=true;}
   if(grounded){position.y=surface;velocity.y=0;if(input.jump&&t.jumping)velocity.y=t.jumpSpeed;}velocity.y-=t.gravity*(float)dt;position+=velocity*(float)dt;if(position.y<surface&&velocity.y<0){position.y=surface;velocity.y=0;}
   position.x=Mathf.Clamp(position.x,-scene.bounds,scene.bounds);position.z=Mathf.Clamp(position.z,-scene.bounds,scene.bounds);if(position.y<t.killY){position=checkpoint;velocity=Vector3.zero;}
  }
  public void Step(double dt,Controls input){
   if(Status!="playing")return;if(dt<=0||dt>.05)throw new ArgumentOutOfRangeException(nameof(dt));elapsed+=dt;
   if(scene.profile=="vehicle-racer")Drive(dt,input);else Walk(dt,input);
   foreach(var o in scene.objects){float d=Vector3.Distance(position,new Vector3(o.x,o.y,o.z));if(o.role=="collectible"&&d<Math.Max(1,Math.Max(o.sx,o.sz)*.6))collected.Add(o.id);if(o.role=="checkpoint"&&d<1.3f)checkpoint=new Vector3(o.x,o.y+.5f,o.z);if(o.role=="finish"&&d<1.5&&collected.Count>=scene.goal&&scene.profile!="management-sim"&&scene.profile!="hazard-survival")Status="won";}
   if(scene.profile=="hazard-survival"){
    if(t.hazardSpawnInterval>0&&elapsed>=nextSpawn&&hazards.Count<24){uint r=Numbers.Pattern(spawned++,37);double angle=r%6283/1000.0;hazards.Add(new Hazard{id="spawn-"+spawned,x=Math.Cos(angle)*(scene.bounds-t.hazardRadius),z=Math.Sin(angle)*(scene.bounds-t.hazardRadius),vx=-Math.Cos(angle)*t.hazardSpeed,vz=-Math.Sin(angle)*t.hazardSpeed,radius=t.hazardRadius});nextSpawn+=t.hazardSpawnInterval;}
    foreach(var h in hazards){h.x+=h.vx*dt;h.z+=h.vz*dt;if(Math.Abs(h.x)>scene.bounds-h.radius){h.x=Numbers.Clamp(h.x,-scene.bounds+h.radius,scene.bounds-h.radius);h.vx*= -1;}if(Math.Abs(h.z)>scene.bounds-h.radius){h.z=Numbers.Clamp(h.z,-scene.bounds+h.radius,scene.bounds-h.radius);h.vz*= -1;}if(elapsed>=invulnerable&&Numbers.Hypot(h.x-position.x,h.z-position.z)<=h.radius+Math.Max(.2,Math.Min(hero.sx,hero.sz)/2)){health=Math.Max(0,health-t.hazardDamage);invulnerable=elapsed+.85;position=checkpoint;velocity=Vector3.zero;if(health==0)Status="lost";}}
    if(Status=="playing"&&elapsed>=scene.seconds)Status="won";
   }else if(scene.profile=="management-sim"){
    if(input.interact)BuildFacility();for(int i=0;i<facilityDue.Count;i++)while(elapsed>=facilityDue[i]){cash+=t.facilityRevenue;facilityDue[i]+=Math.Max(.1,t.facilityInterval);}if(cash>=t.targetCash)Status="won";
    else if(scene.seconds>0&&elapsed>=scene.seconds)Status="lost";
   }else if(Status=="playing"&&scene.seconds>0&&elapsed>=scene.seconds)Status="lost";
  }
  public IEnumerable<Actor> Actors{get{
   foreach(var o in scene.objects){if(collected.Contains(o.id)||o.role=="hazard"&&scene.profile=="hazard-survival")continue;yield return new Actor{id=o.id,role=o.role,recipe=o.meshRecipe,position=o.role=="player"?position:new Vector3(o.x,o.y,o.z),scale=new Vector3(o.sx,o.sy,o.sz)};}
   if(scene.profile=="hazard-survival")foreach(var h in hazards)yield return new Actor{id=h.id,role="hazard",recipe="rock",position=new Vector3((float)h.x,.65f,(float)h.z),scale=Vector3.one*(float)(h.radius*2)};
   if(scene.profile=="management-sim")for(int i=scene.objects.Count(o=>o.role=="facility");i<facilityDue.Count;i++)yield return new Actor{id="facility-extra-"+i,role="facility",recipe="building",position=new Vector3(i*2.5f,0,3),scale=Vector3.one*2};
  }}
 }
}
