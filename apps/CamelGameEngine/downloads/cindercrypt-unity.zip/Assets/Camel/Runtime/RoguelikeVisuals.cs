using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
namespace Camel.Native {
 // Presentation only: reads adapter state and never advances or mutates gameplay.
 public sealed class RoguelikeVisuals:MonoBehaviour {
  const float Tile=.96f; Camera cameraView; Light lantern,key; readonly List<Light> loot=new List<Light>();
  readonly List<Label> labels=new List<Label>(); readonly Dictionary<string,int> enemyHp=new Dictionary<string,int>();readonly Dictionary<string,Vector2Int> enemyCells=new Dictionary<string,Vector2Int>();
  int lastTurn=-1,lastFloor=-1,playerHp; SourceToneMapping tone;
  class Label {public string text;public Color color;public Vector3 position;public float time;}
  public static Vector3 World(Vector2Int p,float height=0)=>new Vector3(p.x*Tile,height,-p.y*Tile);
  static Color Hex(string value){ColorUtility.TryParseHtmlString(value,out var c);return c;}
  Light CreateLight(string name,LightType type,string color,float intensity,float range=0){var o=new GameObject(name);o.transform.SetParent(transform,false);var l=o.AddComponent<Light>();l.type=type;l.color=Hex(color);l.intensity=intensity;l.range=range;l.renderMode=LightRenderMode.ForcePixel;return l;}
  // Built-in Unity ambient/attenuation differs from Three.js; these renderer gains are visually calibrated.
  public void Configure(Camera view,Art art){cameraView=view;cameraView.allowHDR=true;cameraView.backgroundColor=Hex("#100e18");RenderSettings.fog=false;
   foreach(var l in FindObjectsByType<Light>(FindObjectsSortMode.None))l.enabled=false;
   RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=Hex("#88aaff")*(art.ambientIntensity*.75f);RenderSettings.ambientGroundColor=Hex("#222233")*(art.ambientIntensity*.75f);RenderSettings.ambientEquatorColor=(RenderSettings.ambientSkyColor+RenderSettings.ambientGroundColor)*.5f;
   key=CreateLight("Source warm key",LightType.Directional,"#ffddaa",art.keyIntensity/Mathf.PI);key.shadows=LightShadows.Soft;key.shadowBias=.05f;key.shadowNormalBias=.4f;key.shadowCustomResolution=1024;key.transform.rotation=Quaternion.LookRotation(new Vector3(-5,-10,5));
   var rim=CreateLight("Source teal rim",LightType.Directional,"#44ddcc",1.4f/1.75f);rim.transform.rotation=Quaternion.LookRotation(new Vector3(5,-5,-5));
   lantern=CreateLight("Player lantern",LightType.Point,"#ffaa55",4.5f/Mathf.PI,5);
   for(int i=0;i<4;i++)loot.Add(CreateLight("Pooled loot light "+i,LightType.Point,"#ffaa55",3/Mathf.PI,3));
   QualitySettings.pixelLightCount=8;QualitySettings.shadows=ShadowQuality.All;QualitySettings.shadowDistance=60;QualitySettings.antiAliasing=4;
   tone=cameraView.gameObject.AddComponent<SourceToneMapping>();tone.exposure=art.exposure;
  }
  public IEnumerable<Actor> Actors(RoguelikeAdapter g){
   foreach(var p in g.seen){if(Math.Max(Math.Abs(p.x-g.player.x),Math.Abs(p.y-g.player.y))>8)continue;bool walk=g.map.Walk(p);yield return A("tile-"+p.x+"-"+p.y,walk?"floor":"wall","terrain",p,Tile,walk?.1f:.65f);}
   yield return A("hero","player","player",g.player,.65f,1);
   var weapon=g.inventory.FirstOrDefault(i=>i.id==g.weapon);if(weapon!=null){var a=A("equipped-"+weapon.id,MeshKey(weapon.type),"weapon",g.player,.4f,.55f);a.position+=new Vector3(.3f,.5f,0);yield return a;}
   foreach(var e in g.enemies)if(g.map.Sight(g.player,e.cell))yield return A(e.id,"enemy","enemy:"+e.type,e.cell,.6f,e.type=="guardian"?1.2f:.8f);
   foreach(var i in g.items)if(g.map.Sight(g.player,i.cell))yield return A(i.id,MeshKey(i.type),"loot",i.cell,.4f,.55f);
   if(g.seen.Contains(g.map.stairs))for(int i=0;i<3;i++){var a=A("stairs-"+i,"floor","terrain",g.map.stairs,Tile,.1f);a.position.y=i*.15f;yield return a;}
  }
  static string MeshKey(string type)=>type=="blade"?"sword":type=="scroll"?"relic":type;
  static Actor A(string id,string mesh,string role,Vector2Int cell,float w,float h)=>new Actor{id=id,recipe=mesh,role=role,position=new Vector3(cell.x*Tile,0,cell.y*Tile),scale=new Vector3(w,h,w)};
  public void Present(RoguelikeAdapter g){float width=Screen.width,height=Screen.height,side=Mathf.Min(340,width*.32f);cameraView.rect=new Rect(0,0,(width-side)/width,(height-49)/height);cameraView.orthographic=true;cameraView.orthographicSize=5.76f/cameraView.aspect;var p=World(g.player);cameraView.transform.position=p+new Vector3(14,14,-14);cameraView.transform.LookAt(p);cameraView.nearClipPlane=.1f;cameraView.farClipPlane=100;
   lantern.transform.position=p+new Vector3(.5f,1.5f,-.5f);
   var items=g.items.Where(i=>g.map.Sight(g.player,i.cell)).OrderBy(i=>Dungeon.Distance(i.cell,g.player)).Take(4).ToArray();for(int i=0;i<loot.Count;i++){loot[i].enabled=i<items.Length;if(i<items.Length)loot[i].transform.position=World(items[i].cell,.5f);}
   bool advanced=lastFloor==g.floor&&g.turn>lastTurn;
   if(advanced){labels.Clear();foreach(var old in enemyHp){var e=g.enemies.FirstOrDefault(v=>v.id==old.Key);if(e!=null&&e.hp<old.Value)Add("-"+(old.Value-e.hp),Color.red,World(e.cell,1));else if(e==null&&enemyCells.TryGetValue(old.Key,out var cell))Add("DEFEATED",Color.yellow,World(cell,1)); }if(g.hp!=playerHp)Add((g.hp>playerHp?"+":"")+(g.hp-playerHp),g.hp>playerHp?Color.green:Color.red,p+Vector3.up);}
   if(g.turn<lastTurn||g.floor!=lastFloor)labels.Clear();enemyHp.Clear();enemyCells.Clear();foreach(var e in g.enemies){enemyHp[e.id]=e.hp;enemyCells[e.id]=e.cell;}lastTurn=g.turn;lastFloor=g.floor;playerHp=g.hp;
  }
  void OnDestroy(){if(tone!=null)Destroy(tone);}
  void Add(string text,Color color,Vector3 position){if(labels.Count>=32)labels.RemoveAt(0);labels.Add(new Label{text=text,color=color,position=position,time=Time.unscaledTime});}
  void OnGUI(){if(cameraView==null)return;GUI.matrix=Matrix4x4.identity;var style=new GUIStyle(GUI.skin.label){fontSize=16,fontStyle=FontStyle.Bold,alignment=TextAnchor.MiddleCenter};for(int i=labels.Count-1;i>=0;i--){var l=labels[i];float t=(Time.unscaledTime-l.time)/.65f;if(t>=1){labels.RemoveAt(i);continue;}var p=cameraView.WorldToScreenPoint(l.position);style.normal.textColor=new Color(l.color.r,l.color.g,l.color.b,1-t);GUI.Label(new Rect(p.x-60,Screen.height-p.y-16-t*32,120,32),l.text,style);}}
 }
}
