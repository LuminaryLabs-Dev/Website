using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
namespace Camel.Native {
 public sealed partial class NativePlayer:MonoBehaviour {
  ExportGame game;SceneData scene;IGameAdapter adapter;AuthoredMeshes library;Camera view;RoguelikeVisuals rogueVisuals;
  readonly Dictionary<string,GameObject> actors=new Dictionary<string,GameObject>();
  bool paused,inventoryOpen;int sceneIndex;double clock;Controls touch,pending;string fault;Vector2 inventoryScroll;
  public IGameAdapter Adapter=>adapter;public string Fault=>fault;public string SourceHash=>game?.sourceHash;public int RenderedActors=>actors.Count;
  public void RestartGame(){adapter.Restart();clock=0;pending=touch=new Controls();paused=inventoryOpen=false;Debug.Log("CAMEL_INPUT restart");}
  void Start(){try{game=JsonUtility.FromJson<ExportGame>(Resources.Load<TextAsset>("game").text);library=new AuthoredMeshes(game);view=Camera.main;view.clearFlags=CameraClearFlags.SolidColor;LoadScene(0);Debug.Log("CAMEL_READY "+game.sourceHash);if(RuntimeVerification.Requested())gameObject.AddComponent<RuntimeVerification>();}catch(Exception e){fault=e.Message;Debug.LogException(e);}}
  void LoadScene(int index){foreach(var item in actors.Values)Destroy(item);actors.Clear();sceneIndex=index;scene=game.scenes[index];
   switch(scene.profile){case "turn-based-roguelike":adapter=new RoguelikeAdapter(game);break;case "flight-collectathon":adapter=new FlightAdapter(scene.tuning);break;case "endless-runner":adapter=new RunnerAdapter(scene.tuning);break;case "adventure":case "vehicle-racer":case "hazard-survival":case "management-sim":adapter=new SceneAdapter(scene);break;default:throw new NotSupportedException("Native gameplay mapping unavailable: "+scene.profile);}
   if(rogueVisuals!=null){Destroy(rogueVisuals.gameObject);rogueVisuals=null;}
   clock=0;paused=false;Color background;if(ColorUtility.TryParseHtmlString(scene.art.skyTop??"#142033",out background))view.backgroundColor=background;
   RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=Color.white*Mathf.Clamp(scene.art.ambientIntensity,0,2);var light=FindFirstObjectByType<Light>();light.intensity=Mathf.Clamp(scene.art.sunIntensity,0,5);
   if(ColorUtility.TryParseHtmlString(scene.art.sunColor??"#fff1d4",out var sun))light.color=sun;
   RenderSettings.fog=true;RenderSettings.fogMode=FogMode.Linear;RenderSettings.fogStartDistance=scene.art.fogNear;RenderSettings.fogEndDistance=Mathf.Max(scene.art.fogFar,scene.art.fogNear+1);RenderSettings.fogColor=view.backgroundColor;
   if(adapter is RoguelikeAdapter){var visuals=new GameObject("Roguelike presentation");visuals.transform.SetParent(transform,false);rogueVisuals=visuals.AddComponent<RoguelikeVisuals>();rogueVisuals.Configure(view,scene.art);}
  }
  void Update(){if(adapter==null||fault!=null)return;try{
   if(Input.GetKeyDown(KeyCode.Escape))paused=!paused;if(Input.GetKeyDown(KeyCode.R))RestartGame();
   if(Input.GetKeyDown(KeyCode.I))inventoryOpen=!inventoryOpen;
   if(!paused&&adapter is RoguelikeAdapter rogue){
    if(!inventoryOpen){int dx=Input.GetKeyDown(KeyCode.D)||Input.GetKeyDown(KeyCode.RightArrow)?1:Input.GetKeyDown(KeyCode.A)||Input.GetKeyDown(KeyCode.LeftArrow)?-1:0;int dy=Input.GetKeyDown(KeyCode.W)||Input.GetKeyDown(KeyCode.UpArrow)?-1:Input.GetKeyDown(KeyCode.S)||Input.GetKeyDown(KeyCode.DownArrow)?1:0;if(dx!=0||dy!=0)rogue.Command("move",dx:dx,dy:dx==0?dy:0);if(Input.GetKeyDown(KeyCode.E))rogue.Command(rogue.player==rogue.map.stairs?"descend":"pickup");if(Input.GetKeyDown(KeyCode.Space))rogue.Command("wait");}
   }else if(!paused){var input=touch;input.x+=Input.GetKey(KeyCode.D)||Input.GetKey(KeyCode.RightArrow)?1:Input.GetKey(KeyCode.A)||Input.GetKey(KeyCode.LeftArrow)?-1:0;
    input.y+=Input.GetKey(KeyCode.W)||Input.GetKey(KeyCode.UpArrow)?1:Input.GetKey(KeyCode.S)||Input.GetKey(KeyCode.DownArrow)?-1:0;
    input.jump|=Input.GetKeyDown(KeyCode.Space);input.jumpReleased|=Input.GetKeyUp(KeyCode.Space);input.slide|=Input.GetKeyDown(KeyCode.LeftControl);input.boost|=Input.GetKey(KeyCode.LeftShift);input.interact|=Input.GetKeyDown(KeyCode.E);
    // Fixed simulation steps, bounded catch-up; edge actions are consumed exactly once.
    pending.jump|=input.jump;pending.jumpReleased|=input.jumpReleased;pending.slide|=input.slide;pending.interact|=input.interact;
    clock=Math.Min(clock+Time.unscaledDeltaTime,.2);
    while(clock>=1.0/60){input.jump=pending.jump;input.jumpReleased=pending.jumpReleased;input.slide=pending.slide;input.interact=pending.interact;adapter.Step(1.0/60,input);clock-=1.0/60;pending=new Controls();}
   }
   touch.jump=touch.jumpReleased=touch.slide=touch.interact=false;SyncActors();CameraPose();
  }catch(Exception e){fault=e.Message;paused=true;Debug.LogException(e);}}
  void SyncActors(){var active=new HashSet<string>();foreach(var actor in adapter is RoguelikeAdapter r?rogueVisuals.Actors(r):adapter.Actors){active.Add(actor.id);if(!actors.TryGetValue(actor.id,out var item)){
    var source=(rogueVisuals!=null&&actor.role.StartsWith("enemy:")?scene.objects.FirstOrDefault(o=>o.meshRecipe==actor.role.Substring(6)):null)??scene.objects.FirstOrDefault(o=>o.id==actor.id)??scene.objects.FirstOrDefault(o=>o.meshRecipe==actor.recipe)??scene.objects.FirstOrDefault(o=>o.role==actor.role);
    if(source==null)throw new InvalidOperationException("Authored asset missing for "+actor.role+" / "+actor.recipe);
    item=library.Create(source,actor.id,true,rogueVisuals!=null?actor.role:null);actors.Add(actor.id,item);
   }item.SetActive(true);item.transform.position=AuthoredMeshes.World(actor.position);item.transform.localScale=actor.scale;}
   foreach(var id in actors.Keys.Where(k=>!active.Contains(k)).ToArray()){Destroy(actors[id]);actors.Remove(id);}
  }
  void CameraPose(){if(adapter is RoguelikeAdapter r){rogueVisuals.Present(r);return;}var p=AuthoredMeshes.World(adapter.Position);if(scene.profile=="flight-collectathon"){view.transform.position=new Vector3(p.x*.35f,p.y*.35f+1,scene.tuning.flightCameraDistance);view.transform.LookAt(new Vector3(p.x*.5f,p.y*.5f,-16));view.fieldOfView=65;}
   else if(scene.profile=="endless-runner"){view.transform.position=new Vector3(0,5,9);view.transform.LookAt(new Vector3(0,1,-10));view.fieldOfView=60;}
   else {view.orthographic=adapter is RoguelikeAdapter;view.orthographicSize=8;view.transform.position=p+new Vector3(scene.tuning.cameraX,scene.tuning.cameraY,scene.tuning.cameraZ);view.transform.LookAt(p);view.fieldOfView=scene.tuning.cameraFov;}}
  void OnApplicationPause(bool value){if(value)paused=true;}
  void OnGUI(){if(adapter is RoguelikeAdapter r&&fault==null){RogueGUI(r);return;}float scale=Mathf.Max(1,Screen.height/720f);GUI.matrix=Matrix4x4.Scale(Vector3.one*scale);float width=Screen.width/scale,height=Screen.height/scale;
   GUI.Label(new Rect(18,12,width-160,45),fault??adapter?.Hud??"Loading authored game");if(GUI.Button(new Rect(width-115,12,100,40),"Menu"))paused=!paused;
   if(fault!=null)return;
   if(adapter is RoguelikeAdapter rogue&&!paused&&rogue.Status=="playing"){if(GUI.Button(new Rect(width-225,12,100,40),"Inventory"))inventoryOpen=!inventoryOpen;
    if(rogue.upgrade){GUILayout.BeginArea(new Rect(width/2-150,80,300,200),"Upgrade",GUI.skin.window);foreach(var option in new[]{"might","vitality","guard"})if(GUILayout.Button(option,GUILayout.Height(40)))rogue.Command("upgrade",option);GUILayout.EndArea();}
    if(inventoryOpen){GUILayout.BeginArea(new Rect(width-340,65,325,height-90),"Inventory",GUI.skin.window);inventoryScroll=GUILayout.BeginScrollView(inventoryScroll);foreach(var item in rogue.inventory.ToArray()){GUILayout.Label(item.type+" x"+item.quantity+(item.type=="wand"?" charges "+item.charges:"")+(rogue.weapon==item.id||rogue.armor==item.id?" (equipped)":""));GUILayout.BeginHorizontal();if(GUILayout.Button("Equip"))rogue.Command("equip",item.id);if(GUILayout.Button("Use"))rogue.Command("use",item.id);if(GUILayout.Button("Drop"))rogue.Command("drop",item.id);GUILayout.EndHorizontal();}foreach(var enemy in rogue.enemies.Where(e=>rogue.map.Sight(rogue.player,e.cell,5)).ToArray())if(GUILayout.Button("Cast at "+enemy.id))rogue.Command("ranged",enemy.id);GUILayout.EndScrollView();GUILayout.EndArea();}
    if(Application.isMobilePlatform){if(GUI.Button(new Rect(20,height-90,70,65),"Left"))rogue.Command("move",dx:-1);if(GUI.Button(new Rect(170,height-90,70,65),"Right"))rogue.Command("move",dx:1);if(GUI.Button(new Rect(95,height-160,70,65),"Up"))rogue.Command("move",dy:-1);if(GUI.Button(new Rect(95,height-90,70,65),"Down"))rogue.Command("move",dy:1);if(GUI.Button(new Rect(width-110,height-90,90,65),"Interact"))rogue.Command(rogue.player==rogue.map.stairs?"descend":"pickup");if(GUI.Button(new Rect(width-210,height-90,90,65),"Wait"))rogue.Command("wait");}return;
   }
   if(paused||adapter?.Status!="playing"){GUI.Box(new Rect(width/2-180,height/2-125,360,250),game?.title);GUILayout.BeginArea(new Rect(width/2-160,height/2-90,320,220));GUILayout.Label(paused?"Paused":adapter?.Status);if(GUILayout.Button("Resume",GUILayout.Height(36)))paused=false;if(GUILayout.Button("Restart",GUILayout.Height(36)))RestartGame();if(adapter?.Status=="won"&&sceneIndex+1<game.scenes.Length&&GUILayout.Button("Next scene",GUILayout.Height(36)))LoadScene(sceneIndex+1);GUILayout.Label("WASD / arrows: move. Space: jump. Ctrl: slide. Shift: boost. E: interact. R: restart.");GUILayout.EndArea();return;}
   if(Application.isMobilePlatform){touch.x=(GUI.RepeatButton(new Rect(130,height-100,70,70),"Right")?1:0)-(GUI.RepeatButton(new Rect(20,height-100,70,70),"Left")?1:0);touch.y=(GUI.RepeatButton(new Rect(75,height-180,70,70),"Up")?1:0)-(GUI.RepeatButton(new Rect(75,height-75,70,70),"Down")?1:0);if(GUI.Button(new Rect(width-100,height-100,80,70),"Jump"))touch.jump=true;if(GUI.Button(new Rect(width-195,height-100,80,70),"Slide"))touch.slide=true;touch.boost=GUI.RepeatButton(new Rect(width-100,height-180,80,60),"Boost");if(GUI.Button(new Rect(width-195,height-180,80,60),"Interact"))touch.interact=true;}
  }
  void OnDestroy(){library?.Dispose();}
 }
}
