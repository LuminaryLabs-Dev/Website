using System;
using System.IO;
using System.Linq;
using System.Collections;
using UnityEngine;
namespace Camel.Native {
 // Opt-in test mode drives the same native commands; it never edits simulation state.
 public sealed class RuntimeVerification:MonoBehaviour {
  [Serializable]public class Receipt{public string sourceHash,platform,status,error;public bool rendered,moved,combat,inventory,loss,restarted;public int frames,actors;}
  public static bool Requested(){if(Environment.GetCommandLineArgs().Contains("-camelVerify"))return true;
   #if UNITY_ANDROID && !UNITY_EDITOR
   using(var unity=new AndroidJavaClass("com.unity3d.player.UnityPlayer"))using(var activity=unity.GetStatic<AndroidJavaObject>("currentActivity"))using(var intent=activity.Call<AndroidJavaObject>("getIntent"))return intent.Call<bool>("getBooleanExtra","camel.verify",false);
   #else
   return false;
   #endif
  }
  IEnumerator Start(){var player=GetComponent<NativePlayer>();var receipt=new Receipt{sourceHash=player.SourceHash,platform=Application.platform.ToString(),status="running"};int startFrame=Time.frameCount;
   for(int i=0;i<15;i++)yield return null;
   receipt.actors=player.RenderedActors;receipt.rendered=receipt.actors>0&&FindObjectsByType<MeshRenderer>(FindObjectsSortMode.None).Any(r=>r.isVisible&&r.sharedMaterial.shader.isSupported);
   var initial=player.Adapter.Position;
   if(player.Adapter is RoguelikeAdapter rogue){
    for(int i=0;i<350&&rogue.Status=="playing";i++){
     if(rogue.upgrade){rogue.Command("upgrade","might");yield return null;continue;}
     if(!receipt.inventory){var at=rogue.items.FirstOrDefault(p=>p.cell==rogue.player);if(at!=null){receipt.inventory=rogue.Command("pickup");yield return null;continue;}}
     var target=!receipt.inventory?rogue.items.OrderBy(p=>Dungeon.Distance(p.cell,rogue.player)).Select(p=>p.cell).FirstOrDefault():rogue.enemies.OrderBy(p=>Dungeon.Distance(p.cell,rogue.player)).Select(p=>p.cell).FirstOrDefault();
     var next=rogue.map.NextStep(rogue.player,target,new System.Collections.Generic.HashSet<Vector2Int>());int hpBefore=rogue.enemies.Sum(e=>e.hp);if(next!=rogue.player)rogue.Command("move",dx:next.x-rogue.player.x,dy:next.y-rogue.player.y);else rogue.Command("wait");receipt.combat|=rogue.enemies.Sum(e=>e.hp)<hpBefore;receipt.moved|=player.Adapter.Position!=initial;
     yield return new WaitForSeconds(.03f);
    }receipt.loss=rogue.Status=="lost";
   }else {
    for(int i=0;i<120&&player.Adapter.Status=="playing";i++){player.Adapter.Step(1.0/60,new Controls{x=i<30?.3:0});receipt.moved|=player.Adapter.Position!=initial;yield return null;}
    float deadline=Time.realtimeSinceStartup+120;while(player.Adapter.Status=="playing"&&Time.realtimeSinceStartup<deadline)yield return null;receipt.loss=player.Adapter.Status=="lost";
   }
   if(player.Fault!=null)receipt.error=player.Fault;player.RestartGame();for(int i=0;i<10;i++)yield return null;receipt.restarted=player.Adapter.Status=="playing"&&Vector3.Distance(player.Adapter.Position,initial)<.1f;
   receipt.frames=Time.frameCount-startFrame;receipt.status=receipt.rendered&&receipt.moved&&receipt.loss&&receipt.restarted&&(!(player.Adapter is RoguelikeAdapter)||(receipt.combat&&receipt.inventory))&&receipt.error==null?"passed":"failed";
   var json=JsonUtility.ToJson(receipt,true);File.WriteAllText(Path.Combine(Application.persistentDataPath,"runtime-verification.json"),json);Debug.Log("CAMEL_RUNTIME_RECEIPT "+JsonUtility.ToJson(receipt));ScreenCapture.CaptureScreenshot(Path.Combine(Application.persistentDataPath,"runtime-verification.png"));
  }
 }
}
