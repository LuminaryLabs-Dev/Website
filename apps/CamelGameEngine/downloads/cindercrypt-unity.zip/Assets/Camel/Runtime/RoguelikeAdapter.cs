using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
namespace Camel.Native {
 // Candidate native mapping. Source trace parity must pass before release certification.
 public sealed class RoguelikeAdapter:IGameAdapter {
  public sealed class Item{public string id,type;public int quantity=1,charges;public Vector2Int cell;}
  public sealed class Enemy{public string id,type;public Vector2Int cell;public int hp,maxHp,attack,defense,range,xp,gold;public bool telegraph;}
  readonly ExportGame game;readonly Tuning tuning;readonly bool endless;
  public Dungeon map;public Vector2Int player;public List<Item> inventory=new List<Item>(),items=new List<Item>();public List<Enemy> enemies=new List<Enemy>();public HashSet<Vector2Int> seen=new HashSet<Vector2Int>();
  public int floor,turn,hp,maxHp,attack,defense,level,xp,gold,phase;public bool upgrade;public string weapon,armor;public string Status{get;private set;}="playing";
  public int Capacity=>endless?12+2*(level-1):12;public Vector3 Position=>new Vector3(player.x,0,player.y);
  public string Hud=>$"Floor {floor}   HP {hp}/{maxHp}   Level {level}   Gold {gold}   Inventory {inventory.Count}/{Capacity}";
  static readonly string[] Types={"pursuer","caster","guardian","shade","warden"};
  static readonly int[] Hp={8,6,30,10,12},Attack={2,3,5,3,1},Xp={5,6,15,8,10},Gold={2,3,10,4,5};
  public RoguelikeAdapter(ExportGame data){game=data;tuning=data.scenes[0].tuning;endless=data.ruleset=="endless-v1";if(!endless&&data.ruleset!="finite-v1")throw new NotSupportedException("Unknown roguelike ruleset");Restart();}
  public void Restart(){floor=level=1;turn=phase=xp=gold=0;upgrade=false;hp=maxHp=(int)tuning.startingHealth;attack=tuning.baseAttack;defense=tuning.baseDefense;Status="playing";weapon="starter-sword";armor=null;inventory.Clear();inventory.Add(new Item{id=weapon,type="sword"});inventory.Add(new Item{id="starter-potions",type="potion",quantity=2});Populate();}
  void Populate(){map=new Dungeon(game.seed,floor,endless);player=map.start;seen.Clear();items.Clear();enemies.Clear();var rng=new SeededRandom(game.seed+":population:"+floor);var cells=map.OpenCells().ToList();rng.Shuffle(cells);var occupied=new HashSet<Vector2Int>{map.start,map.stairs};
   Func<Func<Vector2Int,bool>,Vector2Int?> find=predicate=>{foreach(var c in cells)if(!occupied.Contains(c)&&predicate(c)){occupied.Add(c);return c;}return null;};
   string[] initial={"wand","armor","potion","scroll","blade"};for(int i=0;i<initial.Length;i++){var c=find(p=>i>=3||Dungeon.Distance(p,player)<=5);if(c.HasValue)items.Add(new Item{id=initial[i]+"-"+floor+"-0",type=initial[i],cell=c.Value,charges=initial[i]=="wand"?6:0});}
   if(endless){string[] extra={"potion","scroll","potion","wand","potion","scroll"};for(int i=0;i<extra.Length;i++){var c=find(p=>true);if(c.HasValue)items.Add(new Item{id=extra[i]+"-"+floor+"-extra-"+i,type=extra[i],cell=c.Value,charges=extra[i]=="wand"?6:0});}}
   int count=endless?10+(int)(rng.Next()*11):floor+2;for(int i=0;i<count;i++){string type=endless?Types[i%5]:i==count-1?(floor==3?"guardian":"caster"):(floor==3&&i==count-2?"caster":"pursuer");int k=Array.IndexOf(Types,type);var c=find(p=>Dungeon.Distance(p,player)>=(endless?7:5));if(!c.HasValue)continue;double factor=endless?1+.1*Math.Log(1+floor,2):1;int health=(int)Math.Floor(Hp[k]*factor*tuning.enemyHealthScale+.5);enemies.Add(new Enemy{id="enemy-"+floor+"-"+i,type=type,cell=c.Value,hp=health,maxHp=health,attack=(int)Math.Floor(Attack[k]*factor*tuning.enemyAttackScale+.5),defense=k==2?1:0,range=k==1?4:1,xp=Xp[k],gold=Gold[k]});}Reveal();
  }
  void Reveal(){for(int y=player.y-6;y<=player.y+6;y++)for(int x=player.x-6;x<=player.x+6;x++){var p=new Vector2Int(x,y);if(x>=0&&y>=0&&x<map.size&&y<map.size&&map.Sight(player,p))seen.Add(p);}}
  int Power=>attack+(inventory.FirstOrDefault(i=>i.id==weapon)?.type=="blade"?5:inventory.FirstOrDefault(i=>i.id==weapon)?.type=="sword"?3:inventory.FirstOrDefault(i=>i.id==weapon)?.type=="wand"?1:0);
  int Defense=>defense+(armor!=null?2:0);
  void Hit(Enemy e,int damage){e.hp=Math.Max(0,e.hp-Math.Max(1,damage-e.defense));if(e.hp==0){xp+=e.xp;gold+=e.gold;}}
  void Award(){if(Status=="playing"&&!upgrade&&xp>=level*8){xp-=level*8;level++;upgrade=true;}}
  void EndTurn(){enemies.RemoveAll(e=>e.hp<=0);phase++;foreach(var e in enemies.OrderBy(e=>e.id,StringComparer.Ordinal)){int dist=Dungeon.Distance(e.cell,player);
    if(endless&&e.type=="warden"&&phase%2==0){foreach(var ally in enemies.Where(a=>a!=e&&Dungeon.Distance(a.cell,e.cell)<=2))ally.hp=Math.Min(ally.maxHp,ally.hp+4);continue;}
    if(endless&&e.type=="guardian"){if(e.telegraph){if(dist==1)hp=Math.Max(0,hp-Math.Max(1,e.attack-Defense));e.telegraph=false;if(hp==0){Status="lost";break;}continue;}if(dist==1){e.telegraph=true;continue;}}
    if(e.type=="caster"){if((!endless||phase%3==0)&&map.Sight(e.cell,player,e.range))hp=Math.Max(0,hp-Math.Max(1,e.attack-Defense));}
    else if(dist==1)hp=Math.Max(0,hp-Math.Max(1,e.attack-Defense));
    else if(dist<=8){var blocked=new HashSet<Vector2Int>(enemies.Where(a=>a!=e).Select(a=>a.cell));if(endless&&e.type=="shade"&&e.hp<e.maxHp*.3){foreach(var d in Dungeon.Directions){var n=e.cell+d;if(map.Walk(n)&&n!=player&&!blocked.Contains(n)&&Dungeon.Distance(n,player)>dist){e.cell=n;break;}}}else{var next=map.NextStep(e.cell,player,blocked);if(next!=player)e.cell=next;}}
    if(hp==0){Status="lost";break;}
   }turn++;Reveal();Award();}
  public bool Command(string action,string id=null,int dx=0,int dy=0){if(Status!="playing")return false;if(upgrade){if(action!="upgrade"||!new[]{"might","vitality","guard"}.Contains(id))return false;if(id=="might")attack+=2;if(id=="vitality"){maxHp+=6;hp+=6;}if(id=="guard")defense++;upgrade=false;Award();return true;}
   switch(action){
    case "move":if(Math.Abs(dx)+Math.Abs(dy)!=1)return false;var next=player+new Vector2Int(dx,dy);if(!map.Walk(next))return false;var target=enemies.FirstOrDefault(e=>e.cell==next);if(target!=null)Hit(target,Power);else player=next;break;
    case "wait":break;
    case "pickup":var ground=items.FirstOrDefault(i=>i.cell==player);if(ground==null||inventory.Count>=Capacity)return false;items.Remove(ground);inventory.Add(ground);break;
    case "equip":var eq=inventory.FirstOrDefault(i=>i.id==id);if(eq==null)return false;if(eq.type=="armor"){if(armor==id)return false;armor=id;}else if(new[]{"sword","blade","wand"}.Contains(eq.type)){if(weapon==id)return false;weapon=id;}else return false;break;
    case "unequip":if(id=="weapon"&&weapon!=null)weapon=null;else if(id=="armor"&&armor!=null)armor=null;else return false;break;
    case "drop":var drop=inventory.FirstOrDefault(i=>i.id==id);if(drop==null||items.Any(i=>i.cell==player))return false;inventory.Remove(drop);drop.cell=player;items.Add(drop);if(weapon==id)weapon=null;if(armor==id)armor=null;break;
    case "use":var use=inventory.FirstOrDefault(i=>i.id==id);if(use==null)return false;if(use.type=="potion"){if(hp==maxHp)return false;hp=Math.Min(maxHp,hp+12);}else if(use.type=="scroll"){var targets=enemies.Where(e=>map.Sight(player,e.cell)).ToArray();if(targets.Length==0)return false;foreach(var e in targets)Hit(e,8);}else return false;if(--use.quantity<=0)inventory.Remove(use);break;
    case "ranged":var wand=inventory.FirstOrDefault(i=>i.id==weapon&&i.type=="wand");var victim=enemies.FirstOrDefault(e=>e.id==id);if(wand==null||wand.charges<1||victim==null||!map.Sight(player,victim.cell,5))return false;wand.charges--;Hit(victim,7);break;
    case "descend":if(player!=map.stairs)return false;if(!endless&&floor>=3){if(enemies.Any(e=>e.type=="guardian"))return false;Status="won";turn++;return true;}floor++;Populate();hp=Math.Min(maxHp,hp+(int)Math.Floor(maxHp*.3+.5));if(endless&&inventory.Count<Capacity)inventory.Add(new Item{id="potion-"+floor+"-descend",type="potion"});turn++;return true;
    default:return false;
   }EndTurn();return true;
  }
  public void Step(double dt,Controls input){if(input.x!=0)Command("move",dx:Math.Sign(input.x));else if(input.y!=0)Command("move",dy:-Math.Sign(input.y));else if(input.interact){if(player==map.stairs)Command("descend");else Command("pickup");}}
  public IEnumerable<Actor> Actors{get{foreach(var p in seen){if(Math.Abs(p.x-player.x)>9||Math.Abs(p.y-player.y)>9)continue;yield return new Actor{id="tile-"+p.x+"-"+p.y,recipe=map.Walk(p)?"floor":"wall",role="terrain",position=new Vector3(p.x,map.Walk(p)?-.1f:0,p.y),scale=new Vector3(.96f,map.Walk(p)?.1f:.65f,.96f)};}
   yield return new Actor{id="hero",recipe="player",role="player",position=Position,scale=new Vector3(.65f,1,.65f)};if(seen.Contains(map.stairs))yield return new Actor{id="stairs",recipe="chest",role="finish",position=new Vector3(map.stairs.x,.3f,map.stairs.y)};
   foreach(var e in enemies)if(map.Sight(player,e.cell))yield return new Actor{id=e.id,recipe=e.type=="caster"?"caster":"enemy",role="enemy",position=new Vector3(e.cell.x,.5f,e.cell.y)};
   foreach(var i in items)if(seen.Contains(i.cell))yield return new Actor{id=i.id,recipe=i.type=="blade"?"sword":i.type=="scroll"?"relic":i.type,role="collectible",position=new Vector3(i.cell.x,.3f,i.cell.y),scale=Vector3.one*.5f};
  }}
 }
}
