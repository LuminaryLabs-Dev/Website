using System.Linq;
using UnityEngine;
namespace Camel.Native {
 public sealed partial class NativePlayer {
  bool controlsOpen;Font headingFont;
  static Color Html(string h){ColorUtility.TryParseHtmlString(h,out var c);return c;}
  static void Panel(Rect rect,string hex){var old=GUI.color;GUI.color=Html(hex);GUI.DrawTexture(rect,Texture2D.whiteTexture);GUI.color=old;}
  void RogueGUI(RoguelikeAdapter r){GUI.matrix=Matrix4x4.identity;float w=Screen.width,h=Screen.height,side=Mathf.Min(340,w*.32f),x=w-side;
   Panel(new Rect(0,0,w,49),"#11131a");Panel(new Rect(x,49,side,h-49),"#11131a");Panel(new Rect(0,48,w,1),"#b87333");Panel(new Rect(x,49,1,h-49),"#b87333");
   if(headingFont==null)headingFont=Font.CreateDynamicFontFromOSFont("Georgia",20);
   var title=new GUIStyle(GUI.skin.label){font=headingFont,fontSize=20,alignment=TextAnchor.MiddleCenter};title.normal.textColor=Html("#d4af37");GUI.Label(new Rect(0,4,w,38),game.title.ToUpper()+(string.IsNullOrEmpty(scene.art.subtitle)?"":" · "+scene.art.subtitle.ToUpper()),title);
   var label=new GUIStyle(GUI.skin.label){fontSize=13,wordWrap=true};label.normal.textColor=Html("#f5f5dc");
   int power=r.attack+(r.inventory.FirstOrDefault(i=>i.id==r.weapon)?.type=="blade"?5:r.inventory.FirstOrDefault(i=>i.id==r.weapon)?.type=="sword"?3:r.inventory.FirstOrDefault(i=>i.id==r.weapon)?.type=="wand"?1:0);
   string[] stats={$"HP: {r.hp}/{r.maxHp}",$"Depth: {r.floor}",$"Turn: {r.turn}",$"Level: {r.level}",$"XP: {r.xp}",$"Gold: {r.gold}",$"ATK: {power}",$"DEF: {r.defense+(r.armor!=null?2:0)}",$"Pos: {r.player.x},{r.player.y}",$"Stairs: {r.map.stairs.x},{r.map.stairs.y}"};
   float column=(side-50)/2;for(int i=0;i<stats.Length;i++){var rect=new Rect(x+20+(i%2)*(column+10),69+(i/2)*45,column,35);Panel(rect,"#2a2d35");Panel(new Rect(rect.x+1,rect.y+1,rect.width-2,rect.height-2),"#1a1c23");GUI.Label(new Rect(rect.x+8,rect.y+8,rect.width-12,22),stats[i],label);}
   GUILayout.BeginArea(new Rect(x+20,300,side-40,h-320));GUILayout.Label("Enemies",title);var visible=r.enemies.Where(e=>r.map.Sight(r.player,e.cell)).ToArray();if(visible.Length==0)GUILayout.Label("None visible",label);foreach(var enemy in visible)GUILayout.Label(enemy.type+"   "+enemy.hp+" / "+enemy.maxHp,label);GUILayout.Space(15);
   GUILayout.BeginHorizontal();if(GUILayout.Button("Inventory",GUILayout.Height(36)))inventoryOpen=!inventoryOpen;if(GUILayout.Button("Controls",GUILayout.Height(36)))controlsOpen=!controlsOpen;if(GUILayout.Button("Menu",GUILayout.Height(36)))paused=!paused;GUILayout.EndHorizontal();
   if(inventoryOpen){inventoryScroll=GUILayout.BeginScrollView(inventoryScroll,GUILayout.MaxHeight(h*.38f));foreach(var item in r.inventory.ToArray()){GUILayout.Label(item.type+" ×"+item.quantity+(r.weapon==item.id||r.armor==item.id?" • equipped":""),label);GUILayout.BeginHorizontal();if(GUILayout.Button("Equip"))r.Command("equip",item.id);if(GUILayout.Button("Use"))r.Command("use",item.id);if(GUILayout.Button("Drop"))r.Command("drop",item.id);GUILayout.EndHorizontal();}foreach(var enemy in r.enemies.Where(e=>r.map.Sight(r.player,e.cell,5)).ToArray())if(GUILayout.Button("Cast at "+enemy.type))r.Command("ranged",enemy.id);GUILayout.EndScrollView();}
   if(controlsOpen){GUILayout.Space(12);GUILayout.Label("WASD / arrows: move and attack\nE: collect / descend\nSpace: wait   ·   I: inventory\nR: restart   ·   Esc: pause",label);}GUILayout.EndArea();
   if(r.upgrade&&!paused){GUILayout.BeginArea(new Rect(w/2-150,90,300,210),"Choose an upgrade",GUI.skin.window);foreach(var option in new[]{"might","vitality","guard"})if(GUILayout.Button(option,GUILayout.Height(45)))r.Command("upgrade",option);GUILayout.EndArea();}
   if(paused||r.Status!="playing"){Panel(new Rect(w/2-180,h/2-115,360,230),"#211c23");GUILayout.BeginArea(new Rect(w/2-160,h/2-95,320,200));GUILayout.Label(paused?"Paused":"Your covenant ends",title);if(paused&&GUILayout.Button("Resume",GUILayout.Height(40)))paused=false;if(GUILayout.Button("Restart",GUILayout.Height(40)))RestartGame();GUILayout.EndArea();}
  }
 }
}
