using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
namespace Camel.Native {
 public sealed class AuthoredMeshes:IDisposable {
  readonly Dictionary<string,Mesh> meshes=new Dictionary<string,Mesh>();
  readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
  public static Vector3 World(Vector3 p)=>new Vector3(p.x,p.y,-p.z);
  public AuthoredMeshes(ExportGame game){
   foreach(var data in game.meshes){
    int count=data.positions.Length/3;var vertices=new Vector3[count];
    for(int i=0;i<count;i++)vertices[i]=World(new Vector3(data.positions[i*3],data.positions[i*3+1],data.positions[i*3+2]));
    var triangles=(int[])data.indices.Clone();for(int i=0;i<triangles.Length;i+=3){int a=triangles[i+1];triangles[i+1]=triangles[i+2];triangles[i+2]=a;}
    var mesh=new Mesh{name=data.id,indexFormat=count>65535?IndexFormat.UInt32:IndexFormat.UInt16};mesh.vertices=vertices;mesh.triangles=triangles;
    if(data.normals!=null&&data.normals.Length==count*3){var normals=new Vector3[count];for(int i=0;i<count;i++)normals[i]=World(new Vector3(data.normals[i*3],data.normals[i*3+1],data.normals[i*3+2]));mesh.normals=normals;}else mesh.RecalculateNormals();
    var colors=new Color[count];int stride=data.colors!=null&&data.colors.Length==count*4?4:3;
    for(int i=0;i<count;i++)colors[i]=data.colors!=null&&data.colors.Length>=count*stride?new Color(data.colors[i*stride],data.colors[i*stride+1],data.colors[i*stride+2],stride==4?data.colors[i*stride+3]:1):Color.white;
    if(data.id=="wall"&&System.Array.IndexOf(game.profiles,"turn-based-roguelike")>=0)mesh.RecalculateNormals();
    mesh.colors=colors;mesh.RecalculateBounds();meshes.Add(data.id,mesh);
   }
  }
  public GameObject Create(ObjectData source,string name,bool normalize,string variant=null){
   if(!meshes.TryGetValue(source.meshId,out var mesh))throw new InvalidOperationException("No authored mesh for "+name+": "+source.meshId);
   var root=new GameObject(name);var child=new GameObject("Authored mesh");child.transform.SetParent(root.transform,false);child.AddComponent<MeshFilter>().sharedMesh=mesh;
   string materialKey=(source.id??source.meshId)+"|"+variant;
   if(!materials.TryGetValue(materialKey,out var mat)){
    var shader=Shader.Find("Camel/Authored PBR");if(shader==null)throw new InvalidOperationException("Missing authored PBR shader");mat=new Material(shader);
    var c=source.color;mat.color=c!=null&&c.Length>=3?new Color(c[0],c[1],c[2],c.Length>3?c[3]:1):Color.white;
    mat.SetFloat("_Metallic",source.metallic);mat.SetFloat("_Glossiness",1-source.roughness);var e=source.emission;if(e!=null&&e.Length>=3)mat.SetColor("_EmissionColor",new Color(e[0],e[1],e[2]));ApplyVariant(mat,variant);materials.Add(materialKey,mat);
   }
   var renderer=child.AddComponent<MeshRenderer>();renderer.sharedMaterial=mat;renderer.receiveShadows=true;
   if(normalize&&source.role=="dungeon-mesh"){var size=mesh.bounds.size;float span=Mathf.Max(.0001f,Mathf.Max(size.x,size.z));var scale=new Vector3(1/span,1/Mathf.Max(.0001f,size.y),1/span);child.transform.localScale=scale;child.transform.localPosition=-Vector3.Scale(new Vector3(mesh.bounds.center.x,mesh.bounds.min.y,mesh.bounds.center.z),scale);}
   else if(normalize){var size=mesh.bounds.size;float span=source.meshRecipe=="hoop"?Mathf.Max(size.x,size.y):Mathf.Max(size.x,size.y,size.z);span=Mathf.Max(.0001f,span);child.transform.localScale=Vector3.one/span;child.transform.localPosition=-mesh.bounds.center/span;}
   return root;
  }
  static Color Hex(string h){ColorUtility.TryParseHtmlString(h,out var c);return c;}
  static void ApplyVariant(Material mat,string variant){
   if(variant==null)return;mat.SetFloat("_DoubleSidedNormals",1);mat.SetFloat("_Metallic",.1f);mat.SetFloat("_Glossiness",.3f);
   if(variant=="player"){mat.SetFloat("_Metallic",.45f);mat.SetFloat("_Glossiness",.62f);}
   if(variant=="loot"){mat.color=Hex("#ffcc88");mat.SetColor("_EmissionColor",Hex("#ffaa55")*1.2f);}
   if(variant.StartsWith("enemy:")){mat.SetFloat("_Metallic",.03f);mat.SetFloat("_Glossiness",.1f);string tint="#ffffff",glow="#411515";float strength=.4f;switch(variant.Substring(6)){case "pursuer":tint="#cc4422";glow="#882211";strength=.6f;break;case "caster":tint="#44aacc";glow="#2288aa";strength=.7f;break;case "guardian":tint="#886644";glow="#664422";strength=.5f;break;case "shade":tint="#442266";glow="#221144";strength=.8f;break;case "warden":tint="#668844";glow="#446622";strength=.5f;break;}mat.color=Hex(tint);mat.SetColor("_EmissionColor",Hex(glow)*strength);}
  }
  public void Dispose(){foreach(var m in meshes.Values)UnityEngine.Object.Destroy(m);foreach(var m in materials.Values)UnityEngine.Object.Destroy(m);meshes.Clear();materials.Clear();}
 }
}
