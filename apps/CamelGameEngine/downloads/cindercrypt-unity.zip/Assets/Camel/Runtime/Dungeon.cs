using System;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;
namespace Camel.Native {
 public sealed class SeededRandom {
  uint state;
  public SeededRandom(string seed){unchecked{state=2166136261;foreach(char c in seed){state^=c;state*=16777619;}if(state==0)state=1;}}
  public double Next(){unchecked{state^=state<<13;state^=state>>17;state^=state<<5;return state/4294967296.0;}}
  public void Shuffle<T>(List<T> list){for(int i=list.Count-1;i>0;i--){int j=(int)Math.Floor(Next()*(i+1));T a=list[i];list[i]=list[j];list[j]=a;}}
 }
 public sealed class Dungeon {
  public readonly int size;public readonly bool[] cells;public Vector2Int start,stairs;public readonly List<RectInt> rooms=new List<RectInt>();
  public static int Distance(Vector2Int a,Vector2Int b)=>Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y);
  static Vector2Int Center(RectInt r)=>new Vector2Int(r.x+r.width/2,r.y+r.height/2);
  public Dungeon(string seed,int floor,bool endless){size=endless?29:17;cells=new bool[size*size];string scope=seed+":floor:"+floor;var rng=new SeededRandom(scope);int count=endless?6:4,min=endless?5:3,max=endless?8:5;
   for(int attempt=0;attempt<count*24&&rooms.Count<count;attempt++){int w=min+(int)(rng.Next()*(max-min+1)),h=min+(int)(rng.Next()*(max-min+1));if(w>=size-2||h>=size-2)continue;var r=new RectInt(1+(int)(rng.Next()*Math.Max(1,size-w-2)),1+(int)(rng.Next()*Math.Max(1,size-h-2)),w,h);if(rooms.All(q=>q.xMax+1<=r.x||r.xMax+1<=q.x||q.yMax+1<=r.y||r.yMax+1<=q.y))rooms.Add(r);}
   if(rooms.Count<2){rooms.Clear();int n=Math.Max(2,Math.Min(4,size-2));rooms.Add(new RectInt(1,1,n,n));rooms.Add(new RectInt(size-n-1,size-n-1,n,n));}
   var sorted=rooms.OrderBy(r=>Center(r).x+Center(r).y).ToArray();rooms.Clear();rooms.AddRange(sorted);foreach(var r in rooms)for(int y=r.y;y<r.yMax;y++)for(int x=r.x;x<r.xMax;x++)cells[y*size+x]=true;
   for(int i=1;i<rooms.Count;i++){var a=Center(rooms[i-1]);var b=Center(rooms[i]);byte[] hash;using(var sha=SHA256.Create())hash=sha.ComputeHash(Encoding.UTF8.GetBytes(scope+":connector-"+i));bool horizontal=hash[hash.Length-1]%2==0;if(horizontal){Line(a,new Vector2Int(b.x,a.y));Line(new Vector2Int(b.x,a.y),b);}else{Line(a,new Vector2Int(a.x,b.y));Line(new Vector2Int(a.x,b.y),b);}}
   start=Center(rooms[0]);stairs=Center(rooms[rooms.Count-1]);
  }
  void Line(Vector2Int a,Vector2Int b){while(true){cells[a.y*size+a.x]=true;if(a==b)break;a+=new Vector2Int(Math.Sign(b.x-a.x),Math.Sign(b.y-a.y));}}
  public bool Walk(Vector2Int p)=>p.x>=0&&p.y>=0&&p.x<size&&p.y<size&&cells[p.y*size+p.x];
  public bool Sight(Vector2Int a,Vector2Int b,int range=6){if(Distance(a,b)>range)return false;int steps=Math.Max(Math.Abs(b.x-a.x),Math.Abs(b.y-a.y));for(int i=1;i<steps;i++){var p=new Vector2Int((int)Math.Floor(a.x+(b.x-a.x)*(double)i/steps+.5),(int)Math.Floor(a.y+(b.y-a.y)*(double)i/steps+.5));if(!Walk(p))return false;}return true;}
  public IEnumerable<Vector2Int> OpenCells(){for(int y=0;y<size;y++)for(int x=0;x<size;x++)if(cells[y*size+x])yield return new Vector2Int(x,y);}
  public static readonly Vector2Int[] Directions={new Vector2Int(-1,0),new Vector2Int(0,-1),new Vector2Int(0,1),new Vector2Int(1,0)};
  public Vector2Int NextStep(Vector2Int from,Vector2Int to,HashSet<Vector2Int> blocked){var queue=new Queue<Vector2Int>();var previous=new Dictionary<Vector2Int,Vector2Int>();queue.Enqueue(from);previous[from]=from;while(queue.Count>0){var p=queue.Dequeue();if(p==to){while(previous[p]!=from&&p!=from)p=previous[p];return p;}foreach(var d in Directions){var n=p+d;if(!Walk(n)||blocked.Contains(n)||previous.ContainsKey(n))continue;previous[n]=p;queue.Enqueue(n);}}return from;}
 }
}
