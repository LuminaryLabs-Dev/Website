Shader "Camel/Authored PBR" {
 Properties { _DoubleSidedNormals("Back-face normals",Float)=0 _Color("Tint",Color)=(1,1,1,1) _Metallic("Metallic",Range(0,1))=0 _Glossiness("Smoothness",Range(0,1))=0.4 _EmissionColor("Emission",Color)=(0,0,0,1) }
 SubShader { Tags { "RenderType"="Opaque" } LOD 200 Cull Off
 CGPROGRAM
 #pragma surface surf Standard fullforwardshadows
 #pragma target 3.0
 struct Input { float4 color:COLOR; float facing:VFACE; };
 fixed4 _Color,_EmissionColor; half _Metallic,_Glossiness,_DoubleSidedNormals;
 void surf(Input IN,inout SurfaceOutputStandard o){o.Normal=float3(0,0,_DoubleSidedNormals<.5||IN.facing>=0?1:-1);o.Albedo=IN.color.rgb*_Color.rgb;o.Metallic=_Metallic;o.Smoothness=_Glossiness;o.Emission=_EmissionColor.rgb;o.Alpha=1;}
 ENDCG
 } FallBack "Diffuse"
}
