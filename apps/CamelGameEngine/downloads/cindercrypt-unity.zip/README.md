# Cindercrypt native Unity project

Open in Unity 6000.3.23f1, open Assets/Scenes/Game.unity, and press Play. Native C# gameplay and authored meshes are included. No server or API key is required.

Windows gameplay checks passed: rendering, movement, combat, inventory, defeat and restart. See windows-runtime.json for artifact-bound evidence. The simulation controller is unchanged from the prior verified export.

Presentation maps the source meshes and vertex colors, role materials, camera, warm key/teal rim, player/loot lights, ACES, equipped weapon, stairs and combat labels. See visual-review.json. Native PBR/light attenuation/shadowing and GUI fonts differ visibly from Three.js; this is not pixel-perfect parity or a full all-adapter certification. Other limitations remain in export.json.
